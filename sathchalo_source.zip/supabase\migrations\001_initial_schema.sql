-- ============================================================
-- SathChalo: Full PostGIS Schema Migration
-- Run this in Supabase SQL Editor after enabling PostGIS extension
-- ============================================================

-- Step 1: Enable PostGIS
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS postgis_topology;

-- ============================================================
-- PROFILES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  phone TEXT UNIQUE,
  avatar_url TEXT,
  rating NUMERIC(3,2) DEFAULT 5.0,
  total_rides INTEGER DEFAULT 0,
  is_driver BOOLEAN DEFAULT FALSE,
  vehicle_make TEXT,
  vehicle_model TEXT,
  vehicle_color TEXT,
  vehicle_plate TEXT,
  vehicle_seats INTEGER DEFAULT 4,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view all profiles"
  ON public.profiles FOR SELECT USING (true);

CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);

-- ============================================================
-- RIDES TABLE (PostGIS LineString for route)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.rides (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  driver_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  origin_address TEXT NOT NULL,
  destination_address TEXT NOT NULL,
  origin_lat DOUBLE PRECISION NOT NULL,
  origin_lng DOUBLE PRECISION NOT NULL,
  destination_lat DOUBLE PRECISION NOT NULL,
  destination_lng DOUBLE PRECISION NOT NULL,
  route_polyline TEXT NOT NULL,           -- Encoded polyline from Google Directions
  route_geom GEOMETRY(LINESTRING, 4326),  -- PostGIS spatial LineString
  available_seats INTEGER NOT NULL DEFAULT 3,
  price_per_seat NUMERIC(10,2) DEFAULT 0,
  departure_time TIMESTAMPTZ NOT NULL,
  status TEXT NOT NULL DEFAULT 'scheduled'
    CHECK (status IN ('scheduled', 'active', 'completed', 'cancelled')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.rides ENABLE ROW LEVEL SECURITY;

-- Spatial index for fast geo-queries
CREATE INDEX IF NOT EXISTS rides_route_geom_idx 
  ON public.rides USING GIST (route_geom);

CREATE POLICY "Anyone can view scheduled/active rides"
  ON public.rides FOR SELECT USING (status IN ('scheduled', 'active'));

CREATE POLICY "Drivers can create rides"
  ON public.rides FOR INSERT WITH CHECK (auth.uid() = driver_id);

CREATE POLICY "Drivers can update own rides"
  ON public.rides FOR UPDATE USING (auth.uid() = driver_id);

-- ============================================================
-- BOOKINGS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ride_id UUID NOT NULL REFERENCES public.rides(id) ON DELETE CASCADE,
  passenger_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  pickup_address TEXT NOT NULL,
  dropoff_address TEXT NOT NULL,
  pickup_lat DOUBLE PRECISION NOT NULL,
  pickup_lng DOUBLE PRECISION NOT NULL,
  dropoff_lat DOUBLE PRECISION NOT NULL,
  dropoff_lng DOUBLE PRECISION NOT NULL,
  otp_code TEXT NOT NULL DEFAULT LPAD(FLOOR(RANDOM() * 10000)::TEXT, 4, '0'),
  otp_verified BOOLEAN DEFAULT FALSE,
  seats_requested INTEGER NOT NULL DEFAULT 1,
  fare_amount NUMERIC(10,2) DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'accepted', 'rejected', 'in_progress', 'completed', 'cancelled')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(ride_id, passenger_id)
);

ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Passengers can view own bookings"
  ON public.bookings FOR SELECT 
  USING (auth.uid() = passenger_id OR 
         auth.uid() = (SELECT driver_id FROM public.rides WHERE id = ride_id));

CREATE POLICY "Passengers can create bookings"
  ON public.bookings FOR INSERT WITH CHECK (auth.uid() = passenger_id);

CREATE POLICY "Drivers and passengers can update bookings"
  ON public.bookings FOR UPDATE 
  USING (auth.uid() = passenger_id OR 
         auth.uid() = (SELECT driver_id FROM public.rides WHERE id = ride_id));

-- ============================================================
-- LIVE LOCATIONS TABLE (Real-time heartbeats)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.live_locations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE UNIQUE,
  ride_id UUID REFERENCES public.rides(id) ON DELETE SET NULL,
  lat DOUBLE PRECISION NOT NULL,
  lng DOUBLE PRECISION NOT NULL,
  heading DOUBLE PRECISION DEFAULT 0,
  speed DOUBLE PRECISION DEFAULT 0,
  location GEOMETRY(POINT, 4326),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.live_locations ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS live_locations_geom_idx
  ON public.live_locations USING GIST (location);

CREATE POLICY "Anyone can view live locations"
  ON public.live_locations FOR SELECT USING (true);

CREATE POLICY "Users can upsert own location"
  ON public.live_locations FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own location"
  ON public.live_locations FOR UPDATE USING (auth.uid() = user_id);

-- ============================================================
-- POSTGIS FUNCTIONS: The 400m Corridor Engine
-- ============================================================

-- Function 1: Find rides whose route corridor intersects both pickup and dropoff
CREATE OR REPLACE FUNCTION public.find_matching_rides(
  pickup_lat DOUBLE PRECISION,
  pickup_lng DOUBLE PRECISION,
  dropoff_lat DOUBLE PRECISION,
  dropoff_lng DOUBLE PRECISION,
  corridor_meters INTEGER DEFAULT 400
)
RETURNS TABLE (
  ride_id UUID,
  driver_id UUID,
  driver_name TEXT,
  driver_rating NUMERIC,
  vehicle_make TEXT,
  vehicle_model TEXT,
  vehicle_color TEXT,
  vehicle_plate TEXT,
  origin_address TEXT,
  destination_address TEXT,
  available_seats INTEGER,
  price_per_seat NUMERIC,
  departure_time TIMESTAMPTZ,
  origin_lat DOUBLE PRECISION,
  origin_lng DOUBLE PRECISION,
  distance_to_pickup_m DOUBLE PRECISION
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  pickup_point GEOMETRY;
  dropoff_point GEOMETRY;
BEGIN
  -- Build the pickup and dropoff geometry points
  pickup_point := ST_SetSRID(ST_MakePoint(pickup_lng, pickup_lat), 4326);
  dropoff_point := ST_SetSRID(ST_MakePoint(dropoff_lng, dropoff_lat), 4326);

  RETURN QUERY
  SELECT
    r.id AS ride_id,
    r.driver_id,
    p.full_name AS driver_name,
    p.rating AS driver_rating,
    p.vehicle_make,
    p.vehicle_model,
    p.vehicle_color,
    p.vehicle_plate,
    r.origin_address,
    r.destination_address,
    r.available_seats,
    r.price_per_seat,
    r.departure_time,
    r.origin_lat,
    r.origin_lng,
    -- Distance from driver's origin to passenger pickup (meters)
    ST_Distance(
      ST_SetSRID(ST_MakePoint(r.origin_lng, r.origin_lat), 4326)::geography,
      pickup_point::geography
    ) AS distance_to_pickup_m
  FROM public.rides r
  JOIN public.profiles p ON p.id = r.driver_id
  WHERE
    r.status = 'scheduled'
    AND r.available_seats > 0
    AND r.departure_time > NOW()
    -- The 400m BUFFER check: pickup must be within corridor
    AND ST_DWithin(
      r.route_geom::geography,
      pickup_point::geography,
      corridor_meters
    )
    -- The 400m BUFFER check: dropoff must also be within corridor
    AND ST_DWithin(
      r.route_geom::geography,
      dropoff_point::geography,
      corridor_meters
    )
    -- Ensure pickup comes BEFORE dropoff on the route (direction check)
    AND ST_LineLocatePoint(r.route_geom, ST_ClosestPoint(r.route_geom, pickup_point))
      < ST_LineLocatePoint(r.route_geom, ST_ClosestPoint(r.route_geom, dropoff_point))
  ORDER BY distance_to_pickup_m ASC
  LIMIT 20;
END;
$$;

-- Function 2: Verify OTP and start ride
CREATE OR REPLACE FUNCTION public.verify_otp_and_start(
  p_booking_id UUID,
  p_otp_code TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_booking public.bookings;
  v_ride public.rides;
BEGIN
  -- Fetch the booking
  SELECT * INTO v_booking FROM public.bookings WHERE id = p_booking_id;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'message', 'Booking not found');
  END IF;

  -- Check that the caller is the driver
  SELECT * INTO v_ride FROM public.rides WHERE id = v_booking.ride_id;
  IF v_ride.driver_id != auth.uid() THEN
    RETURN jsonb_build_object('success', false, 'message', 'Unauthorized');
  END IF;

  -- Verify OTP
  IF v_booking.otp_code != p_otp_code THEN
    RETURN jsonb_build_object('success', false, 'message', 'Invalid OTP');
  END IF;

  IF v_booking.otp_verified THEN
    RETURN jsonb_build_object('success', false, 'message', 'OTP already used');
  END IF;

  -- Mark OTP as verified and update booking status
  UPDATE public.bookings
  SET otp_verified = TRUE,
      status = 'in_progress',
      updated_at = NOW()
  WHERE id = p_booking_id;

  -- Update ride status to active
  UPDATE public.rides
  SET status = 'active', updated_at = NOW()
  WHERE id = v_booking.ride_id;

  RETURN jsonb_build_object('success', true, 'message', 'Ride started successfully');
END;
$$;

-- Function 3: Upsert live location (called by driver app every ~3s)
CREATE OR REPLACE FUNCTION public.upsert_live_location(
  p_lat DOUBLE PRECISION,
  p_lng DOUBLE PRECISION,
  p_heading DOUBLE PRECISION DEFAULT 0,
  p_speed DOUBLE PRECISION DEFAULT 0,
  p_ride_id UUID DEFAULT NULL
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO public.live_locations (user_id, ride_id, lat, lng, heading, speed, location, updated_at)
  VALUES (
    auth.uid(),
    p_ride_id,
    p_lat,
    p_lng,
    p_heading,
    p_speed,
    ST_SetSRID(ST_MakePoint(p_lng, p_lat), 4326),
    NOW()
  )
  ON CONFLICT (user_id) DO UPDATE SET
    ride_id = EXCLUDED.ride_id,
    lat = EXCLUDED.lat,
    lng = EXCLUDED.lng,
    heading = EXCLUDED.heading,
    speed = EXCLUDED.speed,
    location = EXCLUDED.location,
    updated_at = NOW();
END;
$$;

-- Function 4: Check if driver is within 400m of passenger pickup
CREATE OR REPLACE FUNCTION public.check_driver_proximity(
  p_driver_id UUID,
  p_pickup_lat DOUBLE PRECISION,
  p_pickup_lng DOUBLE PRECISION,
  p_threshold_meters INTEGER DEFAULT 400
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_driver_loc public.live_locations;
  v_distance DOUBLE PRECISION;
BEGIN
  SELECT * INTO v_driver_loc FROM public.live_locations WHERE user_id = p_driver_id;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('within_range', false, 'distance_m', -1, 'message', 'Driver location not found');
  END IF;

  v_distance := ST_Distance(
    v_driver_loc.location::geography,
    ST_SetSRID(ST_MakePoint(p_pickup_lng, p_pickup_lat), 4326)::geography
  );

  RETURN jsonb_build_object(
    'within_range', v_distance <= p_threshold_meters,
    'distance_m', ROUND(v_distance::NUMERIC, 1),
    'message', CASE WHEN v_distance <= p_threshold_meters THEN 'Driver is nearby' ELSE 'Driver is too far' END
  );
END;
$$;

-- ============================================================
-- REALTIME: Enable for live_locations
-- ============================================================
ALTER PUBLICATION supabase_realtime ADD TABLE public.live_locations;
ALTER PUBLICATION supabase_realtime ADD TABLE public.bookings;
ALTER PUBLICATION supabase_realtime ADD TABLE public.rides;

-- ============================================================
-- TRIGGERS: Auto-update updated_at
-- ============================================================
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

CREATE TRIGGER set_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER set_rides_updated_at
  BEFORE UPDATE ON public.rides
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER set_bookings_updated_at
  BEFORE UPDATE ON public.bookings
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ============================================================
-- TRIGGER: Auto-create profile on user signup
-- ============================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, phone, avatar_url)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'SathChalo User'),
    NEW.phone,
    NEW.raw_user_meta_data->>'avatar_url'
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
