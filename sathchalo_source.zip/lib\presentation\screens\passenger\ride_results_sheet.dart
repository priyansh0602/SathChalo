import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/constants/app_theme.dart';
import '../../../data/models/profile_model.dart';
import '../../../presentation/providers/app_providers.dart';

class RideResultsSheet extends ConsumerStatefulWidget {
  const RideResultsSheet({super.key});

  @override
  ConsumerState<RideResultsSheet> createState() => _RideResultsSheetState();
}

class _RideResultsSheetState extends ConsumerState<RideResultsSheet> {
  GoogleMapController? _mapCtrl;
  final _sheetCtrl = DraggableScrollableController();
  bool _mapInitialized = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _searchRides());
  }

  Future<void> _searchRides() async {
    final search = ref.read(searchProvider);
    if (!search.isComplete) return;

    await ref.read(rideResultsProvider.notifier).searchRides(
          pickup: search.pickupLatLng!,
          dropoff: search.dropoffLatLng!,
        );

    _updateMapMarkers();
  }

  void _updateMapMarkers() {
    final results = ref.read(rideResultsProvider);
    final search = ref.read(searchProvider);
    if (_mapCtrl == null) return;

    final markers = <Marker>{};

    // Pickup marker
    if (search.pickupLatLng != null) {
      markers.add(Marker(
        markerId: const MarkerId('pickup'),
        position: search.pickupLatLng!,
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
        infoWindow: InfoWindow(title: 'Pickup: ${search.pickupAddress}'),
      ));
    }

    // Dropoff marker
    if (search.dropoffLatLng != null) {
      markers.add(Marker(
        markerId: const MarkerId('dropoff'),
        position: search.dropoffLatLng!,
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
        infoWindow: InfoWindow(title: 'Dropoff: ${search.dropoffAddress}'),
      ));
    }

    // Driver markers from results
    for (final ride in results.rides) {
      markers.add(Marker(
        markerId: MarkerId('driver_${ride.id}'),
        position: LatLng(ride.originLat, ride.originLng),
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure),
        infoWindow: InfoWindow(
          title: ride.driver?.fullName ?? 'Driver',
          snippet: '${ride.availableSeats} seats • ${ride.departureTimeFormatted}',
        ),
        onTap: () {
          ref.read(rideResultsProvider.notifier).selectRide(ride);
        },
      ));
    }

    ref.read(homeMapProvider.notifier).state = HomeMapState(markers: markers);

    // Fit map to show both pickup and dropoff
    if (search.pickupLatLng != null && search.dropoffLatLng != null) {
      final mapsService = ref.read(mapsServiceProvider);
      final bounds = mapsService.boundsFromLatLngList(
          [search.pickupLatLng!, search.dropoffLatLng!]);
      _mapCtrl!.animateCamera(CameraUpdate.newLatLngBounds(bounds, 60));
    }
  }

  Future<void> _requestSeat(RideModel ride) async {
    final profile = ref.read(authProvider);
    if (profile == null) return;

    final search = ref.read(searchProvider);
    if (!search.isComplete) return;

    await ref.read(passengerBookingProvider.notifier).requestSeat(
          ride: ride,
          passengerId: profile.id,
          pickupAddress: search.pickupAddress,
          dropoffAddress: search.dropoffAddress,
          pickupLatLng: search.pickupLatLng!,
          dropoffLatLng: search.dropoffLatLng!,
        );

    _showBookingConfirmation(ride);
  }

  void _showBookingConfirmation(RideModel ride) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => _BookingPendingSheet(ride: ride),
    );
  }

  @override
  Widget build(BuildContext context) {
    final search = ref.watch(searchProvider);
    final results = ref.watch(rideResultsProvider);
    final location = ref.watch(locationProvider);

    return Scaffold(
      body: Stack(
        children: [
          // ─── Map ──────────────────────────────────────────────────────────
          GoogleMap(
            initialCameraPosition: CameraPosition(
              target: search.pickupLatLng ??
                  LatLng(AppConstants.defaultLat, AppConstants.defaultLng),
              zoom: 13,
            ),
            myLocationEnabled: true,
            myLocationButtonEnabled: false,
            zoomControlsEnabled: false,
            mapToolbarEnabled: false,
            compassEnabled: false,
            onMapCreated: (ctrl) {
              _mapCtrl = ctrl;
              ctrl.setMapStyle(AppTheme.mapStyle);
              _updateMapMarkers();
            },
          ),

          // ─── Back Button ──────────────────────────────────────────────────
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    boxShadow: AppTheme.cardShadow,
                  ),
                  child: const Icon(Icons.arrow_back,
                      size: 20, color: AppTheme.textPrimary),
                ),
              ),
            ),
          ),

          // ─── Bottom Sheet ─────────────────────────────────────────────────
          DraggableScrollableSheet(
            controller: _sheetCtrl,
            initialChildSize: 0.42,
            minChildSize: 0.12,
            maxChildSize: 0.85,
            builder: (context, scrollCtrl) => Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(24)),
                boxShadow: AppTheme.bottomSheetShadow,
              ),
              child: CustomScrollView(
                controller: scrollCtrl,
                slivers: [
                  // Handle
                  SliverToBoxAdapter(
                    child: Center(
                      child: Container(
                        width: 36,
                        height: 4,
                        margin: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: AppTheme.divider,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                  ),

                  // Header
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                      child: Row(
                        mainAxisAlignment:
                            MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                results.isLoading
                                    ? 'Searching...'
                                    : '${results.rides.length} rides found',
                                style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w800,
                                    color: AppTheme.textPrimary),
                              ),
                              Text(
                                _shortAddress(search.dropoffAddress),
                                style: const TextStyle(
                                    fontSize: 12,
                                    color: AppTheme.textSecondary),
                              ),
                            ],
                          ),
                          if (!results.isLoading)
                            TextButton.icon(
                              onPressed: _searchRides,
                              icon: const Icon(Icons.refresh,
                                  size: 16, color: AppTheme.textSecondary),
                              label: const Text('Refresh',
                                  style: TextStyle(
                                      fontSize: 12,
                                      color: AppTheme.textSecondary)),
                            ),
                        ],
                      ),
                    ),
                  ),

                  // Content
                  if (results.isLoading)
                    const SliverFillRemaining(
                      child: Center(
                        child: CircularProgressIndicator(
                            strokeWidth: 2.5, color: AppTheme.primary),
                      ),
                    )
                  else if (results.rides.isEmpty)
                    SliverFillRemaining(child: _NoRidesFound())
                  else
                    SliverList(
                      delegate: SliverChildBuilderDelegate(
                        (context, i) => _RideCard(
                          ride: results.rides[i],
                          onRequestSeat: () =>
                              _requestSeat(results.rides[i]),
                        ),
                        childCount: results.rides.length,
                      ),
                    ),

                  const SliverToBoxAdapter(child: SizedBox(height: 32)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _shortAddress(String address) {
    final parts = address.split(',');
    return parts.isNotEmpty ? parts.first.trim() : address;
  }
}

// ─── Ride Card ────────────────────────────────────────────────────────────────
class _RideCard extends StatelessWidget {
  final RideModel ride;
  final VoidCallback onRequestSeat;

  const _RideCard({required this.ride, required this.onRequestSeat});

  @override
  Widget build(BuildContext context) {
    final driver = ride.driver;

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.divider),
        boxShadow: AppTheme.cardShadow,
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              children: [
                // Driver info row
                Row(
                  children: [
                    // Avatar
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: AppTheme.primary,
                        shape: BoxShape.circle,
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        driver?.initials ?? 'D',
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 16),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            driver?.fullName ?? 'Driver',
                            style: const TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 15,
                                color: AppTheme.textPrimary),
                          ),
                          Row(
                            children: [
                              const Icon(Icons.star_rounded,
                                  color: Colors.amber, size: 13),
                              const SizedBox(width: 2),
                              Text(
                                driver?.rating.toStringAsFixed(1) ?? '5.0',
                                style: const TextStyle(
                                    fontSize: 12,
                                    color: AppTheme.textSecondary),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                '• ${driver?.vehicleModel ?? 'Car'}',
                                style: const TextStyle(
                                    fontSize: 12,
                                    color: AppTheme.textSecondary),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    // Price
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          ride.pricePerSeat != null
                              ? '₹${ride.pricePerSeat!.toStringAsFixed(0)}'
                              : 'Free',
                          style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                              color: AppTheme.textPrimary),
                        ),
                        const Text('per seat',
                            style: TextStyle(
                                fontSize: 11,
                                color: AppTheme.textSecondary)),
                      ],
                    ),
                  ],
                ),

                const SizedBox(height: 12),
                const Divider(height: 1),
                const SizedBox(height: 12),

                // Route info
                Row(
                  children: [
                    Expanded(
                      child: _InfoChip(
                        icon: Icons.access_time_rounded,
                        label: ride.departureTimeFormatted,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _InfoChip(
                        icon: Icons.airline_seat_recline_normal_rounded,
                        label: '${ride.availableSeats} seats left',
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _InfoChip(
                        icon: Icons.directions_car_rounded,
                        label: driver?.vehicleNumber ?? '—',
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),

                // Corridor badge
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppTheme.accent.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.near_me_rounded,
                          size: 12, color: AppTheme.accent),
                      const SizedBox(width: 5),
                      Text(
                        'Route passes within 400m of your location',
                        style: TextStyle(
                            fontSize: 11,
                            color: AppTheme.accent,
                            fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Request button
          GestureDetector(
            onTap: ride.hasSeats ? onRequestSeat : null,
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                color: ride.hasSeats
                    ? AppTheme.primary
                    : AppTheme.divider,
                borderRadius: const BorderRadius.vertical(
                    bottom: Radius.circular(16)),
              ),
              alignment: Alignment.center,
              child: Text(
                ride.hasSeats ? 'Request Seat' : 'Full',
                style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: ride.hasSeats
                        ? Colors.white
                        : AppTheme.textSecondary),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Info Chip ────────────────────────────────────────────────────────────────
class _InfoChip extends StatelessWidget {
  final IconData icon;
  final String label;

  const _InfoChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
      decoration: BoxDecoration(
        color: AppTheme.background,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: AppTheme.textSecondary),
          const SizedBox(width: 4),
          Flexible(
            child: Text(
              label,
              style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textPrimary),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── No Rides Found ───────────────────────────────────────────────────────────
class _NoRidesFound extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: AppTheme.background,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.directions_car_outlined,
                  size: 36, color: AppTheme.textSecondary),
            ),
            const SizedBox(height: 16),
            const Text(
              'No rides found',
              style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.textPrimary),
            ),
            const SizedBox(height: 8),
            const Text(
              'No drivers are going your way right now.\nTry a different time or destination.',
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 13,
                  color: AppTheme.textSecondary,
                  height: 1.5),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Booking Pending Sheet ────────────────────────────────────────────────────
class _BookingPendingSheet extends ConsumerWidget {
  final RideModel ride;

  const _BookingPendingSheet({required this.ride});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final bookingState = ref.watch(passengerBookingProvider);
    final booking = bookingState.activeBooking;

    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 36,
            height: 4,
            margin: const EdgeInsets.only(bottom: 24),
            decoration: BoxDecoration(
              color: AppTheme.divider,
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // Status icon
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              color: booking?.isAccepted == true
                  ? AppTheme.accent.withOpacity(0.12)
                  : AppTheme.warning.withOpacity(0.12),
              shape: BoxShape.circle,
            ),
            child: Icon(
              booking?.isAccepted == true
                  ? Icons.check_circle_rounded
                  : Icons.access_time_rounded,
              size: 36,
              color: booking?.isAccepted == true
                  ? AppTheme.accent
                  : AppTheme.warning,
            ),
          ),
          const SizedBox(height: 16),

          Text(
            booking?.isAccepted == true
                ? 'Booking Accepted!'
                : 'Request Sent!',
            style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: AppTheme.textPrimary),
          ),
          const SizedBox(height: 8),

          Text(
            booking?.isAccepted == true
                ? 'Your seat is confirmed. Show the OTP to your driver.'
                : 'Waiting for ${ride.driver?.fullName ?? "driver"} to accept your request...',
            textAlign: TextAlign.center,
            style: const TextStyle(
                fontSize: 14,
                color: AppTheme.textSecondary,
                height: 1.5),
          ),

          // OTP display (once accepted)
          if (booking?.isAccepted == true && booking?.otp != null) ...[
            const SizedBox(height: 24),
            const Text('Your OTP',
                style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.textSecondary)),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 32, vertical: 16),
              decoration: BoxDecoration(
                color: AppTheme.primary,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Text(
                booking!.otp!,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 40,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 12,
                ),
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'Share this with your driver when they arrive',
              style: TextStyle(
                  fontSize: 12, color: AppTheme.textSecondary),
            ),
          ] else ...[
            const SizedBox(height: 24),
            const LinearProgressIndicator(
              color: AppTheme.primary,
              backgroundColor: AppTheme.divider,
            ),
          ],

          const SizedBox(height: 24),

          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () => Navigator.pop(context),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size(double.infinity, 48),
                side: const BorderSide(color: AppTheme.divider),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text('Close',
                  style: TextStyle(
                      color: AppTheme.textPrimary,
                      fontWeight: FontWeight.w600)),
            ),
          ),

          const SizedBox(height: 16),
        ],
      ),
    );
  }
}