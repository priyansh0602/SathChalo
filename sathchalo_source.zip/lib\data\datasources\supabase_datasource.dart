import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/profile_model.dart';
import '../../core/constants/app_constants.dart';

class SupabaseDataSource {
  final SupabaseClient _client;

  SupabaseDataSource() : _client = Supabase.instance.client;

  SupabaseClient get client => _client;

  // ─── Auth ────────────────────────────────────────────────────────────────
  User? get currentUser => _client.auth.currentUser;
  String? get currentUserId => _client.auth.currentUser?.id;
  bool get isLoggedIn => currentUser != null;

  Stream<AuthState> get authStateStream => _client.auth.onAuthStateChange;

  Future<AuthResponse> signInWithPhone({
    required String phone,
    required String password,
  }) async {
    return await _client.auth.signInWithPassword(
      phone: phone,
      password: password,
    );
  }

  Future<AuthResponse> signUpWithPhone({
    required String phone,
    required String password,
    required String fullName,
  }) async {
    final resp = await _client.auth.signUp(
      phone: phone,
      password: password,
      data: {'full_name': fullName},
    );
    return resp;
  }

  Future<void> signOut() async => await _client.auth.signOut();

  // Mock login for demo
  Future<ProfileModel> mockLogin({
    required String name,
    required String phone,
  }) async {
    // Create mock profile directly without hitting the database
    return ProfileModel(
      id: '00000000-0000-0000-0000-${phone.replaceAll(' ', '').padLeft(12, '0')}',
      fullName: name,
      phone: phone,
      isDriver: false,
      rating: 5.0,
      totalRides: 0,
      createdAt: DateTime.now(),
    );
  }

  // ─── Profiles ────────────────────────────────────────────────────────────
  Future<ProfileModel?> getProfile(String userId) async {
    try {
      final data = await _client
          .from(AppConstants.profilesTable)
          .select()
          .eq('id', userId)
          .maybeSingle();
      return data != null ? ProfileModel.fromJson(data) : null;
    } catch (_) {
      return null;
    }
  }

  Future<ProfileModel> upsertProfile(ProfileModel profile) async {
    final data = await _client
        .from(AppConstants.profilesTable)
        .upsert(profile.toJson())
        .select()
        .single();
    return ProfileModel.fromJson(data);
  }

  Future<ProfileModel> updateProfile({
    required String userId,
    String? fullName,
    String? vehicleNumber,
    String? vehicleModel,
    String? vehicleColor,
    bool? isDriver,
    String? avatarUrl,
  }) async {
    final updates = <String, dynamic>{};
    if (fullName != null) updates['full_name'] = fullName;
    if (vehicleNumber != null) updates['vehicle_number'] = vehicleNumber;
    if (vehicleModel != null) updates['vehicle_model'] = vehicleModel;
    if (vehicleColor != null) updates['vehicle_color'] = vehicleColor;
    if (isDriver != null) updates['is_driver'] = isDriver;
    if (avatarUrl != null) updates['avatar_url'] = avatarUrl;

    final data = await _client
        .from(AppConstants.profilesTable)
        .update(updates)
        .eq('id', userId)
        .select()
        .single();
    return ProfileModel.fromJson(data);
  }

  // ─── Rides ───────────────────────────────────────────────────────────────
  Future<RideModel> createRide({
    required String driverId,
    required String originAddress,
    required String destinationAddress,
    required double originLat,
    required double originLng,
    required double destinationLat,
    required double destinationLng,
    required String routePolyline,
    required int availableSeats,
    required DateTime departureTime,
    double? pricePerSeat,
    String? notes,
  }) async {
    final data = await _client.from(AppConstants.ridesTable).insert({
      'driver_id': driverId,
      'origin_address': originAddress,
      'destination_address': destinationAddress,
      'origin_lat': originLat,
      'origin_lng': originLng,
      'destination_lat': destinationLat,
      'destination_lng': destinationLng,
      'route_polyline': routePolyline,
      'available_seats': availableSeats,
      'total_seats': availableSeats,
      'departure_time': departureTime.toIso8601String(),
      'status': AppConstants.statusPending,
      'price_per_seat': pricePerSeat,
      'notes': notes,
    }).select().single();
    return RideModel.fromJson(data);
  }

  Future<RideModel?> getRide(String rideId) async {
    try {
      final data = await _client
          .from(AppConstants.ridesTable)
          .select('*, driver:profiles(*)')
          .eq('id', rideId)
          .maybeSingle();
      return data != null ? RideModel.fromJson(data) : null;
    } catch (_) {
      return null;
    }
  }

  Future<List<RideModel>> getActiveRidesByDriver(String driverId) async {
    final data = await _client
        .from(AppConstants.ridesTable)
        .select('*, driver:profiles(*)')
        .eq('driver_id', driverId)
        .inFilter('status', ['pending', 'in_progress'])
        .order('departure_time', ascending: true);
    return (data as List).map((e) => RideModel.fromJson(e)).toList();
  }

  Future<RideModel> updateRideStatus({
    required String rideId,
    required String status,
  }) async {
    final data = await _client
        .from(AppConstants.ridesTable)
        .update({'status': status})
        .eq('id', rideId)
        .select()
        .single();
    return RideModel.fromJson(data);
  }

  // ─── 400m Corridor Matching (RPC) ────────────────────────────────────────
  Future<List<RideModel>> findMatchingRides({
    required double pickupLat,
    required double pickupLng,
    required double dropoffLat,
    required double dropoffLng,
    double radiusMeters = AppConstants.matchRadiusMeters,
  }) async {
    try {
      final data = await _client.rpc(
        AppConstants.rpcFindMatchingRides,
        params: {
          'pickup_lat': pickupLat,
          'pickup_lng': pickupLng,
          'dropoff_lat': dropoffLat,
          'dropoff_lng': dropoffLng,
          'radius_meters': radiusMeters,
        },
      );
      return (data as List).map((e) => RideModel.fromJson(e)).toList();
    } catch (e) {
      // Fallback: return empty list if RPC not available
      return [];
    }
  }

  Future<List<Map<String, dynamic>>> getPassengersOnRoute({
    required String rideId,
    double radiusMeters = AppConstants.matchRadiusMeters,
  }) async {
    try {
      final data = await _client.rpc(
        AppConstants.rpcGetPassengersOnRoute,
        params: {
          'p_ride_id': rideId,
          'radius_meters': radiusMeters,
        },
      );
      return List<Map<String, dynamic>>.from(data as List);
    } catch (_) {
      return [];
    }
  }

  // ─── Bookings ─────────────────────────────────────────────────────────────
  Future<BookingModel> createBooking({
    required String rideId,
    required String passengerId,
    required String pickupAddress,
    required String dropoffAddress,
    required double pickupLat,
    required double pickupLng,
    required double dropoffLat,
    required double dropoffLng,
  }) async {
    // Generate 4-digit OTP
    final otp = (1000 + (DateTime.now().millisecondsSinceEpoch % 9000))
        .toString();

    final data = await _client.from(AppConstants.bookingsTable).insert({
      'ride_id': rideId,
      'passenger_id': passengerId,
      'pickup_address': pickupAddress,
      'dropoff_address': dropoffAddress,
      'pickup_lat': pickupLat,
      'pickup_lng': pickupLng,
      'dropoff_lat': dropoffLat,
      'dropoff_lng': dropoffLng,
      'status': AppConstants.bookingPending,
      'otp': otp,
      'otp_verified': false,
      'requested_at': DateTime.now().toIso8601String(),
    }).select().single();
    return BookingModel.fromJson(data);
  }

  Future<List<BookingModel>> getBookingsByRide(String rideId) async {
    final data = await _client
        .from(AppConstants.bookingsTable)
        .select('*, passenger:profiles(*)')
        .eq('ride_id', rideId)
        .order('requested_at', ascending: false);
    return (data as List).map((e) => BookingModel.fromJson(e)).toList();
  }

  Future<List<BookingModel>> getBookingsByPassenger(String passengerId) async {
    final data = await _client
        .from(AppConstants.bookingsTable)
        .select('*, ride:rides(*, driver:profiles(*))')
        .eq('passenger_id', passengerId)
        .order('requested_at', ascending: false);
    return (data as List).map((e) => BookingModel.fromJson(e)).toList();
  }

  Future<BookingModel> updateBookingStatus({
    required String bookingId,
    required String status,
  }) async {
    final updates = <String, dynamic>{'status': status};
    if (status == AppConstants.bookingAccepted) {
      updates['accepted_at'] = DateTime.now().toIso8601String();
    } else if (status == AppConstants.bookingCompleted) {
      updates['completed_at'] = DateTime.now().toIso8601String();
    }

    final data = await _client
        .from(AppConstants.bookingsTable)
        .update(updates)
        .eq('id', bookingId)
        .select()
        .single();
    return BookingModel.fromJson(data);
  }

  Future<bool> verifyOtp({
    required String bookingId,
    required String otp,
  }) async {
    try {
      final result = await _client.rpc(
        AppConstants.rpcVerifyOtp,
        params: {'p_booking_id': bookingId, 'p_otp': otp},
      );
      // Ensure we return a boolean
      return result == true;
    } catch (_) {
      // Fallback: direct check
      try {
        final data = await _client
            .from(AppConstants.bookingsTable)
            .select('otp')
            .eq('id', bookingId)
            .single();
        final storedOtp = data['otp'] as String?;
        if (storedOtp == otp) {
          await _client
              .from(AppConstants.bookingsTable)
              .update({'otp_verified': true})
              .eq('id', bookingId);
          return true;
        }
      } catch (_) {}
      return false;
    }
  }

  Future<Map<String, dynamic>> verifyOtpAndStart({
    required String bookingId,
    required String otp,
  }) async {
    try {
      final verified = await verifyOtp(bookingId: bookingId, otp: otp);
      if (!verified) {
        return {'success': false, 'message': 'Invalid OTP'};
      }

      await _client
          .from(AppConstants.bookingsTable)
          .update({'status': AppConstants.statusInProgress})
          .eq('id', bookingId);

      return {'success': true};
    } catch (e) {
      return {'success': false, 'message': e.toString()};
    }
  }

  Future<bool> checkDriverProximity({
    required String rideId,
    required double lat,
    required double lng,
  }) async {
    // Basic proximity check - usually done via RPC or Realtime
    return true;
  }

  // ─── Live Locations ───────────────────────────────────────────────────────
  Future<void> upsertLiveLocation({
    required String driverId,
    required double latitude,
    required double longitude,
    double? bearing,
    double? speed,
  }) async {
    await _client.from(AppConstants.liveLocationsTable).upsert({
      'driver_id': driverId,
      'latitude': latitude,
      'longitude': longitude,
      'bearing': bearing,
      'speed': speed,
      'updated_at': DateTime.now().toIso8601String(),
    });
  }

  Future<LiveLocationModel?> getLiveLocation(String driverId) async {
    try {
      final data = await _client
          .from(AppConstants.liveLocationsTable)
          .select()
          .eq('driver_id', driverId)
          .maybeSingle();
      return data != null ? LiveLocationModel.fromJson(data) : null;
    } catch (_) {
      return null;
    }
  }

  Future<void> deleteLiveLocation(String driverId) async {
    await _client
        .from(AppConstants.liveLocationsTable)
        .delete()
        .eq('driver_id', driverId);
  }

  // ─── Realtime Subscriptions ───────────────────────────────────────────────
  RealtimeChannel subscribeToDriverLocation({
    required String driverId,
    required void Function(LiveLocationModel) onUpdate,
  }) {
    return _client
        .channel('driver_location_$driverId')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: AppConstants.liveLocationsTable,
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'driver_id',
            value: driverId,
          ),
          callback: (payload) {
            final newRecord = payload.newRecord;
            if (newRecord.isNotEmpty) {
              onUpdate(LiveLocationModel.fromJson(newRecord));
            }
          },
        )
        .subscribe();
  }

  RealtimeChannel subscribeToBookingUpdates({
    required String rideId,
    required void Function(BookingModel) onUpdate,
  }) {
    return _client
        .channel('booking_updates_$rideId')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: AppConstants.bookingsTable,
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'ride_id',
            value: rideId,
          ),
          callback: (payload) {
            final newRecord = payload.newRecord;
            if (newRecord.isNotEmpty) {
              onUpdate(BookingModel.fromJson(newRecord));
            }
          },
        )
        .subscribe();
  }

  RealtimeChannel subscribeToPassengerBooking({
    required String passengerId,
    required void Function(BookingModel) onUpdate,
  }) {
    return _client
        .channel('passenger_booking_$passengerId')
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: AppConstants.bookingsTable,
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'passenger_id',
            value: passengerId,
          ),
          callback: (payload) {
            final newRecord = payload.newRecord;
            if (newRecord.isNotEmpty) {
              onUpdate(BookingModel.fromJson(newRecord));
            }
          },
        )
        .subscribe();
  }

  void removeChannel(RealtimeChannel channel) {
    _client.removeChannel(channel);
  }
}